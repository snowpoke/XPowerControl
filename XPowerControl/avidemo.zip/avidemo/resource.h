//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Avidemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_AVIDEMO_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDR_AVI                         130
#define IDC_ANIMATE                     1000
#define IDC_PROGRESS                    1001
#define IDC_PROG_BTN                    1002
#define IDC_PERCENT                     1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
